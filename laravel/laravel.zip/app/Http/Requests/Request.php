<?php
/**
 * Created by PhpStorm.
 * User: DouglasSerafim
 * Date: 01/02/2017
 * Time: 10:32
 */

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class Request extends  FormRequest
{

}