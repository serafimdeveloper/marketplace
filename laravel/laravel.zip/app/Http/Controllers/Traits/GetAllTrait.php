<?php

namespace App\Http\Controllers\Traits;

/**
 * Get All Trait.
 *
 * @author Douglas Serafim <douglas.serafim@gmail.com>
 */
trait GetAllTrait
{
    use GetTrait, AllTrait;
}
