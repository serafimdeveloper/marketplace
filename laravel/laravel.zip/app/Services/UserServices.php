<?php
/**
 * Created by PhpStorm.
 * User: DouglasSerafim
 * Date: 29/03/2017
 * Time: 19:20
 */

namespace App\Services;


class UserServices
{

    public function send_email_confirmation(){

    }

}