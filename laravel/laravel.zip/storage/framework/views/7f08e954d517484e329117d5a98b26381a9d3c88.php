<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('accont.inc.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="panel-content">
        <header class="pop-title">
            <h1>Meus pedidos</h1>
        </header>

    <?php if(!$requests): ?>
            <p class="trigger notice fontem-14">Você não realizou compras no site ainda<br>
                <a class="btn btn-small btn-popmartin" href="<?php echo e(route('homepage')); ?>" target="_blank">Comprar agora</a>
            </p>
        <?php else: ?>
        <!-- TABLE -->
            <table class="table table-action">

                <thead>
                <tr>
                    <th class="t-small">Pedidos</th>
                    <th class="t-medium">Data</th>
                    <th class="t-medium">Valor</th>
                    <th class="t-medium">Loja</th>
                    <th class="t-medium">Status</th>
                    <th class="t-small"></th>
                </tr>
                </thead>

                <tbody>
                <?php $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <tr>
                        <td><?php echo e($order->key); ?></td>
                        <td><?php echo e($order->created_at->diffForHumans()); ?></td>
                        <td>R$ <?php echo e($order->amount); ?></td>
                        <td><?php echo e($order->store->name); ?></td>
                        <td class="t-status t-<?php echo e($order->requeststatus->trigger); ?>"><?php echo e($order->requeststatus->description); ?></td>
                        <td class="txt-center"><a href="/accont/requests/<?php echo e($order->id); ?>"
                                                  class="t-popmartin">detalhes</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                </tbody>
            </table>
            <!-- END TABLE -->

            <div class="fl-right"><?php echo $requests->render(); ?></div>
        <?php endif; ?>
    </section>
    <div class="clear-both"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>