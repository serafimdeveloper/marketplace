<?php $__env->startSection('content'); ?>
    <section class="content">
        <?php if(!Session::has('cart') || !(count($cart->stores))): ?>
            <div class="trigger warning">
                <p class="fontem-20">Carrinho vazio</p>
                <a href="/" class="btn btn-small btn-popmartin">
                    <i class="fa fa-shopping-cart"></i>
                    adicionar produto
                </a>
            </div>
        <?php else: ?>
            <header class="pop-title">
                <h1><span id="jq-count-product"><?php echo e($cart->count); ?></span> item no meu carrinho</h1>
            </header>
            <?php $__currentLoopData = $cart->stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_store => $store): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <article class="pop-cart">
                    <h1><?php echo e($store['name']); ?></h1>
                    <div>
                        <table class="table pop-cart-info-product">
                            <thead>
                            <tr>
                                <th></th>
                                <th class="t-medium">Frete</th>
                                <th class="t-medium">Quantidade</th>
                                <th class="t-medium">Preço Unitário</th>
                                <th class="t-medium">Subtotal</th>
                            </tr>
                            </thead>
                            <tbody id="jq-pr-cart">
                            <?php $__currentLoopData = $store['products']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key_product => $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr id="pr<?php echo e($key_store.$key_product); ?>">
                                    <td>
                                        <div class="coltable">
                                            <div class="coltable-2 product-cart-img">
                                                <img src="<?php echo e(url('imagem/produto/'.$product['image'] . '?w120&h=120&fit=cropt')); ?>"
                                                     alt="[]"
                                                     title="">
                                            </div>
                                            <div class="coltable-10 product-cart-info">
                                                <a href="<?php echo e(route('pages.product',['store' => $store['slug'], 'category' => $product['category'], 'product' => $product['slug']])); ?>"
                                                   target="_blank"><span
                                                            class="c-pop fontem-12 fontw-400"><?php echo e($product['name']); ?></span></a>
                                                <br>
                                                <span>Código: 0gos8d4</span>
                                                <br>
                                                <br>
                                                <a class="pop-remove-product-cart c-pop" href="javascript:void(0)"
                                                   data-product="<?php echo e($key_product); ?>">
                                                    <i class="fa fa-trash"></i> remover</a>
                                            </div>
                                        </div>
                                    </td>
                                    <td><?php echo e(($product['free_shipping'] ? 'Grátis' : 'á calcular')); ?></td>
                                    <td class="txt-center">
                                        <form action="javascript:void(0)" class="atualizar-produtos">
                                            <label>
                                                <input type="number" name="qtd" value="<?php echo e($product['qtd']); ?>">
                                            </label>
                                            <input type="hidden" name="product" value="<?php echo e($key_product); ?>"/>
                                            <?php echo e(csrf_field()); ?>

                                            <br>
                                            <button class="c-popdark cursor-pointer"
                                                    style="background: none; border: none;">
                                                <i class="fa fa-refresh"></i>
                                                atualizar
                                            </button>
                                        </form>
                                    </td>
                                    <td class="price"><?php echo e(real($product['price_unit'])); ?></td>
                                    <td class="price" style="font-weight: bold;"><?php echo e(real($product['subtotal'])); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                            </tbody>
                        </table>
                        <div class="pop-cart-footer">
                            <div class="pop-cart-obs">
                                <a href="javascript:void(0)"
                                   class="show-formobs btn btn-small btn-popmartin-trans"><i class="fa fa-comments"></i>
                                    <?php echo e(isset($store['obs']) ? 'ver' : 'adicionar'); ?>

                                    observações a este pedido</a>
                                <form class="form-modern" action="" method="POST">
                                    <?php echo e(csrf_field()); ?>

                                    <input type="hidden" name="store" value="<?php echo e($key_store); ?>">
                                    <label>
                                        <textarea name="note" class="radius"
                                                  placeholder="Exemplo: tamanho, cor, outra informação"><?php echo e($store['obs']); ?></textarea>
                                    </label>
                                    <div class="">
                                        <button type="submit" class="btn btn-small btn-popmartin">Salvar</button>
                                        <a href="javascript:void(0)" class="c-red">cancelar</a>
                                    </div>
                                </form>
                            </div>
                            <div class="pop-cart-subtotal">
                                <div class="colbox">
                                    <div class="colbox-2">
                                        <p class="txt-right" style="margin: 30px 0 20px 0;">
                                            <?php if(isset($cart->address['zip_code']) && isset($address[0])): ?>
                                                <span class="fontem-16">Frete para o CEP: <b><?php echo e($cart->address['zip_code']); ?></b></span>
                                                <br>
                                                <span><?php echo e($address[0]['logradouro'].', '.$address[0]['bairro'].', '.$address[0]['cidade'].' - '.$address[0]['uf']); ?></span>
                                            <?php else: ?>
                                                <span class="fontem-16">Nenhum endereço encontrado</span>
                                            <?php endif; ?>
                                        </p>
                                    </div>
                                    <div class="colbox-2">
                                        <?php if(isset($store['freight'])): ?>
                                            <table>
                                                <tr>
                                                    <td>Subtotal:</td>
                                                    <td><?php echo e(real($store['subtotal'])); ?></td>
                                                </tr>
                                            </table>
                                            <br>
                                            <div class="checkbox-container dp-inblock txt-right">
                                                <div class="checkboxies txt-left">
                                                    <?php $__currentLoopData = $store['freight']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $freight): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                        <label class="radio" style="float: none; display: block;">
                                                        <span>
                                                            <i class="fa <?php echo e(($key === $store['type_freight']['name']) ? 'fa-check-circle-o c-green':'fa-circle-o'); ?>"></i>
                                                            <?php echo e($key. ': '.real($freight['val']).' ('.$freight['deadline'].' dias utéis)'); ?>

                                                        </span>
                                                            <?php echo Form::radio('type_freight', $key, ($key === $store['type_freight']['name']), ['class'=>'type-freight', 'data-store' => $key_store, 'data-token' => csrf_token(), 'data-id' => $freight['id'] ] ); ?>

                                                        </label>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                                </div>
                                            </div>
                                            <br>
                                        <?php endif; ?>
                                        <table>
                                            <tr class="fontem-12">
                                                <td><span class="c-pop fontw-600">Total para esta loja:</span></td>
                                                <td><?php echo e(real($store['amount'])); ?></td>
                                            </tr>
                                        </table>
                                    </div>
                                </div>
                                <div class="clear-both"></div>
                            </div>
                        </div>
                    </div>
                    <div class="txt-right">
                        <?php if($cart->address): ?>
                            <a href="<?php echo e(route('pages.cart.cart_address', ['sha1' => strtoupper(sha1($key_store))])); ?>" class="btn btn-popmartin">enviar pedido desta loja</a>
                        <?php else: ?>
                            <span class="btn btn-gray cursor-nodrop tooltip" title="Necessário informar um cep">enviar pedido</span>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <hr>
            <div class="pop-cart-cep">
                <div class="txt-right">
                    <?php echo Form::open(['route'=>['pages.cart.add_address'],'class'=>'form-modern pop-form freight-form', 'method'=>'POST']); ?>

                    <?php if($addresses): ?>
                        <span>Selecione o endereço</span>
                        <?php echo Form::select('address', $addresses, (isset($cart->address['id']) ? $cart->address['id'] : null), ['class' => 'selectAddressCart', 'placeholder' => 'Selecionar endereço']); ?>

                        <label style="display: inline-block;width: auto;">
                            <?php echo Form::text('zip_code',(isset($cart->address['zip_code']) ? $cart->address['zip_code'] : null), ['class' => 'getCepAddressCart', 'onkeyup' => 'maskInt(this)', 'placeholder' => 'CEP', 'data-minlength' => 8]); ?>

                            <!--<span class="alert <?php echo e($errors->has('zip_code') ? '' : ' hidden'); ?>"><?php echo e($errors->first('zip_code')); ?></span>-->
                        </label>
                    <?php else: ?>
                        <span>Informe o Cep</span>
                        <?php echo Form::text('zip_code', (isset($cart->address['zip_code']) ? $cart->address['zip_code'] : null), ['onkeyup' => 'maskInt(this)', 'placeholder' => 'CEP']); ?>

                        <!--<span class="alert<?php echo e($errors->has('zip_code') ? '' : ' hidden'); ?>"><?php echo e($errors->first('zip_code')); ?></span>-->
                    <?php endif; ?>
                    <button type="submit" class="btn btn-popmartin">calcular</button>
                    <?php echo Form::close(); ?>

                </div>
            </div>
            <br>
            <div class="pop-cart-total">
                <p class="pop-cart-subtotal">Total:
                    <span class="fontw-500 c-pop fontem-12 vertical-middle"><?php echo e(real($cart->amount)); ?></span>
                </p>
                <div class="colbox">
                    <div class="colbox-2 txt-left">
                        <br>
                        <a href="/" class="c-pop"><i class="fa fa-chevron-left vertical-middle"></i> continuar comprando</a>
                    </div>
                    
                        
                            
                                
                        
                            
                        
                    
                </div>
                <div class="clear-both"></div>
            </div>
        <?php endif; ?>
    </section>
    <div class="bs-dialog radius-small" title="Enviar observação para LOJA DO JUCA"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>