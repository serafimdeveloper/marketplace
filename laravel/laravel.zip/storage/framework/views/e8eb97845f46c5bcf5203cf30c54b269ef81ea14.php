<?php $__env->startSection('content'); ?>
    <section class="content">
        <?php if(!$page): ?>
            <div class="trigger warning">
                <h1>Erro 404</h1>

                <h2>Página não encontrada</h2>
            </div>
        <?php else: ?>
            <header class="pop-title">
                <h1><?php echo e($page->title); ?></h1>
            </header>
            <article>
                <?php echo e($page->content); ?>

            </article>
        <?php endif; ?>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>