<?php $__env->startSection('content'); ?>
    <br>
    <section class="content pop-carousel-home">
        <header class="pop-title">
            <h1>Destaque</h1>
        </header>
        <div class="pop-home-prd owl-carousel">
            <?php $__empty_1 = true; $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <article class="modal-product">
                    <ul>
                        <?php if(Auth::check()): ?>
                            <li><a href="javascript:void(0)" class="add-favorite" data-product="<?php echo e($product->id); ?>"
                                   data-message=" para adicionar ao seus favoritos!">
                                    <i class="fa fa-heart <?php echo e(is_favorite($favorites, $product->store_id, $product->id) ? 'c-reddark': ''); ?>"></i>
                                </a></li>
                        <?php else: ?>
                            <li><a href="javascript:void(0)" class="jq-auth"
                                   data-message=" para adicionar ao seus favoritos!"><i class="fa fa-heart"></i></a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <a href="<?php echo e(route('pages.product',['store'=>$product->store->slug,'category'=> $product->category->slug, 'product' => $product->slug])); ?>"
                               onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent('<?php echo e(route('pages.product',['store'=>$product->store->slug,'category'=> $product->category->slug, 'product' => $product->slug])); ?>'),'facebook-share-dialog','width=626,height=436');return false;">
                                <i class="fa fa-facebook-official"></i>
                            </a>
                        </li>
                        <li><a href="javascript:void(0)" data-product="<?php echo e($product->id); ?>" class="add-cart"><i
                                        class="fa fa-cart-plus"></i></a></li>
                    </ul>
                    <figure>
                        <img src="<?php echo e(url('imagem/produto/'.$product->galeries->first()->image.'?w=250&h=250&fit=crop')); ?>"
                             alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>">
                        <figcaption>
                            <a href="<?php echo e(route('pages.product',[$product->store->slug, $product->category->slug, $product->slug])); ?>">
                                <?php echo e(real(isset($product->price_out_discount)? $product->price_out_discount : $product->price)); ?>

                            </a>
                        </figcaption>
                        <?php if($product->free_shipping): ?>
                            <span class="modal-product-frete"><i class="fa fa-truck"></i> frete grátis</span>
                        <?php endif; ?>
                        <?php if($product->price_out_discount): ?>
                            <div class="modal-discont">
                                <span class="modal-product-descont-percent"><?php echo e(discont_percent($product->price, $product->price_out_discount)); ?>

                                    % OFF</span>
                                <span class="modal-product-descont"><?php echo e(isset($product->price_out_discount) ? real($product->price) : ''); ?></span>
                            </div>
                        <?php endif; ?>
                    </figure>
                    <header>
                        <h2>
                            <a href="<?php echo e(route('pages.product',[$product->store->slug, $product->category->slug, $product->slug])); ?>"><?php echo e($product->name); ?></a>
                        </h2>
                        <p class="tagline"><a
                                    href="<?php echo e(route('pages.store',['store' => $product->store->slug])); ?>"><?php echo e($product->store->name); ?></a>
                            <?php echo e(is_favorite($favorites, $product->store_id, $product)); ?>

                        </p>
                    </header>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <?php for($i=0;$i<10;$i++): ?>
                    <article class="modal-product">
                        <ul>
                            <li><a href="javascript:void(0)"><i class="fa fa-heart"></i></a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-facebook-official"></i></a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-cart-plus"></i></a></li>
                        </ul>
                        <figure>
                            <img src="<?php echo e(url('imagem/popmartin/img-exemple.jpg?w=250&h=250&fit=crop')); ?>" alt="[]"
                                 title="">
                            <figcaption><a href="#">R$ 0,00</a></figcaption>
                            <span class="modal-product-frete"></span>
                            <span class="modal-product-descont"></span>
                        </figure>
                        <header>
                            <h2><a href="#">Nome do Produto</a></h2>
                            <p class="tagline"><a href="#">Nome da Loja</a></p>
                        </header>
                    </article>
                <?php endfor; ?>
            <?php endif; ?>
        </div>
        <div class="clear-both"></div>
    </section>
    <section class="content pop-carousel-home">
        <header class="pop-title">
            <h1>Novidades</h1>
        </header>
        <div class="pop-home-prd owl-carousel">
            <?php $__empty_1 = true; $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <article class="modal-product">
                    <ul>
                        <?php if(Auth::check()): ?>
                            <li><a href="javascript:void(0)" class="add-favorite" data-product="<?php echo e($product->id); ?>"
                                   data-message=" para adicionar ao seus favoritos!">
                                    <i class="fa fa-heart <?php echo e(is_favorite($favorites, $product->store_id, $product->id) ? 'c-reddark': ''); ?>"></i>
                                </a></li>
                        <?php else: ?>
                            <li><a href="javascript:void(0)" class="jq-auth"
                                   data-message=" para adicionar ao seus favoritos!"><i class="fa fa-heart"></i></a>
                            </li>
                        <?php endif; ?>
                        <li>
                            <a href="<?php echo e(route('pages.product',['store'=>$product->store->slug,'category'=> $product->category->slug, 'product' => $product->slug])); ?>"
                               onclick="window.open('https://www.facebook.com/sharer/sharer.php?u='+encodeURIComponent('<?php echo e(route('pages.product',['store'=>$product->store->slug,'category'=> $product->category->slug, 'product' => $product->slug])); ?>'),'facebook-share-dialog','width=626,height=436');return false;">
                                <i class="fa fa-facebook-official"></i>
                            </a>
                        </li>
                        <li><a href="javascript:void(0)" data-product="<?php echo e($product->id); ?>" class="add-cart"><i
                                        class="fa fa-cart-plus"></i></a></li>
                    </ul>
                    <figure>
                        <img src="<?php echo e(url('imagem/produto/'.$product->galeries->first()->image.'?w=250&h=250&fit=crop')); ?>"
                             alt="<?php echo e($product->name); ?>" title="<?php echo e($product->name); ?>">
                        <figcaption>
                            <a href="<?php echo e(route('pages.product',[$product->store->slug, $product->category->slug, $product->slug])); ?>">
                                <?php echo e(real(isset($product->price_out_discount)? $product->price_out_discount : $product->price)); ?>

                            </a>
                        </figcaption>
                        <?php if($product->free_shipping): ?>
                            <span class="modal-product-frete"><i class="fa fa-truck"></i> frete grátis</span>
                        <?php endif; ?>
                        <?php if($product->price_out_discount): ?>
                            <div class="modal-discont">
                                <span class="modal-product-descont-percent"><?php echo e(discont_percent($product->price, $product->price_out_discount)); ?>

                                    % OFF</span>
                                <span class="modal-product-descont"><?php echo e(isset($product->price_out_discount) ? real($product->price) : ''); ?></span>
                            </div>
                        <?php endif; ?>
                    </figure>
                    <header>
                        <h2>
                            <a href="<?php echo e(route('pages.product',[$product->store->slug, $product->category->slug, $product->slug])); ?>"><?php echo e($product->name); ?></a>
                        </h2>
                        <p class="tagline"><a
                                    href="<?php echo e(route('pages.store',['store' => $product->store->slug])); ?>"><?php echo e($product->store->name); ?></a>
                        </p>
                    </header>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <?php for($i=0;$i<10;$i++): ?>
                    <article class="modal-product">
                        <ul>
                            <li><a href="javascript:void(0)"><i class="fa fa-heart"></i></a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-facebook-official"></i></a></li>
                            <li><a href="javascript:void(0)"><i class="fa fa-cart-plus"></i></a></li>
                        </ul>
                        <figure>
                            <img src="<?php echo e(url('imagem/popmartin/img-exemple.jpg?w=250&h=250&fit=crop')); ?>" alt="[]"
                                 title="">
                            <figcaption><a href="#">R$ 0,00</a></figcaption>
                            <span class="modal-product-frete"></span>
                            <span class="modal-product-descont"></span>
                        </figure>
                        <header>
                            <h2><a href="#">Nome do Produto</a></h2>
                            <p class="tagline"><a href="#">Nome da Loja</a></p>
                        </header>
                    </article>
                <?php endfor; ?>
            <?php endif; ?>
        </div>
        <div class="clear-both"></div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>