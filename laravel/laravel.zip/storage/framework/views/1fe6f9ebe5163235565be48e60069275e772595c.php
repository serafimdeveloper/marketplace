<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('accont.inc.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="panel-content">
        <div class="colbox">
            <article class="colbox-2">
                <header class="pop-title">
                    <h1>Dados do Usuários</h1>
                </header>
                  <?php echo Form::model($user,['route'=>['accont.home.store'],'method'=>'POST','class'=>'form-modern pop-form']); ?>

                    <label>
                        <span>Nome</span>
                        <?php echo Form::text('name',null, ['placeholder' => 'Seu nome', 'data-required' => 'name']); ?>

                        <span class="alert<?php echo e($errors->has('name') ? '' : ' hidden'); ?>"><?php echo e($errors->first('name')); ?></span>
                    </label>
                    <label>
                        <span>Sobrenome</span>
                        <?php echo Form::text('last_name',null, ['placeholder' => 'Sobrenome', 'data-required' => 'last_name']); ?>

                        <span class="alert<?php echo e($errors->has('last_name') ? '' : ' hidden'); ?>"><?php echo e($errors->first('last_name')); ?></span>
                    </label>
                    <label>
                        <span>Cpf</span>
                        <?php echo Form::text('cpf',null, ['class'=>'masked_cpf','placeholder' => 'Meu CPF', 'data-required' => 'cpf']); ?>

                       <span class="alert<?php echo e($errors->has('cpf') ? '' : ' hidden'); ?>"><?php echo e($errors->first('cpf')); ?></span>
                    </label>
                    <label>
                        <span>Data de Nascimento</span>
                        <?php echo Form::date('birth',null, ['placeholder' => 'data de nascimento']); ?>

                        <span class="alert<?php echo e($errors->has('birth') ? '' : ' hidden'); ?>"><?php echo e($errors->first('birth')); ?></span>
                    </label>
                    <div class="checkbox-container padding10" style="position:relative;">
                        <span>Gênero</span>
                        <div class="checkboxies">
                            <label class="radio" style="border: none;">
                                <span><span class="fa <?php echo e(($user->genre === 'M') ? 'fa-check-circle-o c-green':'fa-circle-o'); ?>"></span> masculino</span>
                                <?php echo Form::radio('genre','M'); ?>

                            </label>
                            <label class="radio" style="border: none;">
                                <span><span class="fa <?php echo e(($user->genre === 'F') ? 'fa-check-circle-o c-green':'fa-circle-o'); ?>"></span> feminino</span>
                                <?php echo Form::radio('genre','F'); ?>

                            </label>
                        </div>
                        <span class="alert<?php echo e($errors->has('genre') ? '' : ' hidden'); ?>"><?php echo e($errors->first('genre')); ?></span>
                    </div>
                <label>
                    <span>Telefone</span>
                    <?php echo Form::text('phone',null, ['placeholder' => 'Informar telefone', 'class' => 'masked_fullphone', 'data-required' => 'fullphone']); ?>

                    <span class="alert<?php echo e($errors->has('phone') ? '' : ' hidden'); ?>"><?php echo e($errors->first('phone')); ?></span>
                </label>
                    <div class="txt-center" style="border-top: 1px solid #B0BEC5;padding-top: 10px;">
                        <button type="submit" class="btn btn-popmartin">atualizar dados</button>
                    </div>
                <?php echo Form::close(); ?>

            </article>
            <div class="colbox-2">
                <header class="pop-title">
                    <h1>Endereços</h1>
                    <div class="pop-tile-menu">
                        <span class="btn btn-smallextreme btn-popmartin jq-address" data-action="user"><i class="fa fa-plus vertical-middle"></i> novo</span>
                    </div>
                </header>
                <div id="group-pnl-end">
                <?php $__empty_1 = true; $__currentLoopData = $adresses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adress): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <div class="panel-end" id="end_<?php echo e($adress->id); ?>">
                        <h4><?php echo e($adress->name); ?> <span class="fl-right address-master"><?php echo $adress->master ? 'principal' : ''; ?></span></h4>
                        <div class="panel-end-content">
                            <p>CEP: <?php echo e($adress->zip_code); ?></p>
                            <p><?php echo e($adress->public_place); ?>, <?php echo e($adress->number); ?> - <?php echo e($adress->city); ?></p>
                        </div>
                        <a href="javascript:void(0)" class="panel-end-edit vertical-flex jq-address" data-id="<?php echo e($adress->id); ?>" data-action="user">editar|excluir</a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                    <div id="isAddress">
                        <p class="trigger warning txt-center"><i class="fa fa-exclamation-circle"></i> Você ainda não possui endereços cadastrado</p>
                        <p class="txt-center"><a href="javascript:void(0)" class="btn btn-popmartin jq-address" data-action="user">cadastrar um endereço</a></p>
                    </div>
                <?php endif; ?>
                </div>
            </div>
        </div>
        <br>
        <hr>
        <div class="content">
            <h2 style="text-align: center;">Dados do conta</h2>
            <?php echo Form::open(['route' => ['accont.changepassword.store'], 'method' => 'POST','class'=>'content form-modern pop-form']); ?>

                <label>
                    <span>email</span>
                    <input type="text" name="email" value="<?php echo e($user->email); ?>" disabled="true" style="color: #FFFFFF;background-color: #888888;">
                </label>
                <label>
                    <span>senha atual</span>
                    <?php echo Form::password('password', [ 'placeholder' => 'Senha', 'data-required' => 'password']); ?>

                    <span class="alert<?php echo e($errors->has('password') ? '' : ' hidden'); ?>"><?php echo e($errors->first('password')); ?></span>
                </label>
                <label>
                    <span>criar nova senha</span>
                    <?php echo Form::password('newpassword', [ 'placeholder' => 'Nova senha', 'data-required' => 'password']); ?>

                    <span class="alert<?php echo e($errors->has('newpassword') ? '' : ' hidden'); ?>"><?php echo e($errors->first('newpassword')); ?></span>
                </label>
                <label>
                    <span>repetir nova senha</span>
                    <?php echo Form::password('newpassword_confirmation', [ 'placeholder' => 'Repita sua nova senha', 'data-required' => 'password']); ?>

                    <span class="alert<?php echo e($errors->has('newpassword_confirmation') ? '' : ' hidden'); ?>"><?php echo e($errors->first('newpassword_confirmation')); ?></span>
                </label>
                <div class="txt-center">
                    <button type="submit" class="btn btn-popmartin">atualizar senha</button>
                </div>
             <?php echo Form::close(); ?>

        </div>
    </section>
    <?php echo $__env->make('layouts.parties.alert_adress', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="clear-both"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>