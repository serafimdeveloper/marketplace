<span class="panel-icon-mobile">menu <i class="fa fa-chevron-down"></i></span>
<nav class="panel-nav">
    <div>
        <div class="panel-nav-acsess">
            <h3>Área do cliente</h3>
            <ul>
                <li>
                    <a href="<?php echo e(route('accont.home')); ?>"<?php echo url()->current() ==  route('accont.home') ? ' class="current_rout"' :  ''; ?>>meu
                        cadastro</a></li>
                <li>
                    <a href="<?php echo e(route('accont.requests')); ?>"<?php echo url()->current() ==  route('accont.requests') ? ' class="current_rout"' :  ''; ?>>meus
                        pedidos</a></li>
                <li>
                    <a href="<?php echo e(route('accont.searchstore')); ?>"<?php echo url()->current() ==  route('accont.searchstore') ? ' class="current_rout"' :  ''; ?>>procurar
                        loja</a></li>
                <li>
                    <a href="<?php echo e(route('accont.messages.box',['type'=>'user', 'box' => 'received'])); ?>"<?php echo url()->current() ==  route('accont.messages.box',['type'=>'user', 'box' => 'received']) ? ' class="current_rout"' :  ''; ?>>mensagens <?php echo (notification_message_client() >= 1 ? '<span class="fl-right padding05-10 radius bg-blue-gray" style="margin-top: -5px;">'.notification_message_client().'</span>' : ''); ?></a>
                </li>
            </ul>
        </div>
        <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('vendedor')): ?>
            <div class="panel-nav-acsess">
                <h3>Área do vendedor</h3>
                <ul>
                    <li>
                        <a href="<?php echo e(route('accont.salesman.info')); ?>"<?php echo url()->current() ==  route('accont.salesman.info') ? ' class="current_rout"' :  ''; ?>>informações</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('accont.salesman.stores')); ?>"<?php echo url()->current() ==  route('accont.salesman.stores') ? ' class="current_rout"' :  ''; ?>>minha
                            loja</a></li>
                    <li>
                        <a href="<?php echo e(route('accont.salesman.products.index')); ?>"<?php echo url()->current() ==  route('accont.salesman.products.index') ? ' class="current_rout"' :  ''; ?>>meus
                            produtos</a></li>
                    <li>
                        <a href="<?php echo e(route('accont.salesman.sales')); ?>"<?php echo url()->current() ==  route('accont.salesman.sales') ? ' class="current_rout"' :  ''; ?>>minhas
                            vendas <?php echo (notification_sales(0) >= 1 ? '<span class="fl-right padding05-10 radius bg-reddark" style="margin-top: -5px;">'.notification_sales(0).'</span>' : ''); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('accont.messages.box',['type'=>'store', 'box' => 'received'])); ?>" <?php echo url()->current() ==  route('accont.messages.box',['type'=>'store', 'box' => 'received']) ? ' class="current_rout"' :  ''; ?>>mensagens <?php echo (notification_message_salesman() >= 1 ? '<span class="fl-right padding05-10 radius bg-blue-gray" style="margin-top: -5px;">'.notification_message_salesman().'</span>' : ''); ?></a>
                    </li>
                </ul>
            </div>
        <?php endif; ?>
        <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->denies('vendedor')): ?>
            <div class="panel-nav-acsess">
                <h3>Área do vendedor</h3>
                <ul>
                    <li>
                        <a href="<?php echo e(route('accont.salesman.info')); ?>"<?php echo url()->current() ==  route('accont.salesman.info') ? ' class="current_rout"' :  ''; ?>>Torna-se
                            um Vendedor</a></li>
                </ul>
            </div>
        <?php endif; ?>
        <?php if (app('Illuminate\Contracts\Auth\Access\Gate')->check('admin')): ?>
            <div class="panel-nav-acsess">
                <h3>Área administrativa</h3>
                <ul>
                    <li>
                        <a href="<?php echo e(route('accont.report.users')); ?>"<?php echo url()->current() ==  route('accont.report.users') ? ' class="current_rout"' :  ''; ?>>Usuários</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('accont.report.salesman')); ?>"<?php echo url()->current() ==  route('accont.report.salesman') ? ' class="current_rout"' :  ''; ?>>vendedores <?php echo (notification_sales(0) >= 1 ? '<span class="fl-right padding05-10 radius bg-blue-gray" style="margin-top: -5px;">'.notification_sales(0).'</span>' : ''); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('accont.report.products')); ?>"<?php echo url()->current() ==  route('accont.report.products') ? ' class="current_rout"' :  ''; ?>>produtos</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('accont.categories.index')); ?>"<?php echo url()->current() ==  route('accont.categories.index') ? ' class="current_rout"' :  ''; ?>>categorias</a>
                    </li>
                    <li>
                        <a href="/accont/banners"<?php echo url()->current() ==  route('accont.home') ? ' class="current_rout"' :  ''; ?>>banners</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('accont.report.sales')); ?>"<?php echo url()->current() ==  route('accont.report.sales') ? ' class="current_rout"' :  ''; ?>>vendas
                            e comissões</a></li>
                    <li>
                        <a href="<?php echo e(route('accont.report.notifications')); ?>"<?php echo url()->current() ==  route('accont.report.notifications') ? ' class="current_rout"' :  ''; ?>>notificações <?php echo (notification_sales(0) >= 1 ? '<span class="fl-right padding05-10 radius bg-blue-gray" style="margin-top: -5px;">'.notification_sales(0).'</span>' : ''); ?></a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('accont.pages')); ?>"<?php echo url()->current() ==  route('accont.pages') ? ' class="current_rout"' :  ''; ?>>páginas</a>
                    </li>
                </ul>
            </div>
        <?php endif; ?>
    </div>
</nav>
<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(url('/js/panel.js')); ?>"></script>
<?php $__env->stopSection(); ?>