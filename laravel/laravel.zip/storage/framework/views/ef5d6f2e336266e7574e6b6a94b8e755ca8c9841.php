<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="pop-title">
            <h1>Finalizar pedido</h1>
        </div>
        <br>
        <p class="txt-center fontem-14 fontw-500 c-graydark">Valor:
            <span class="c-pop"><?php echo e(real($order->amount)); ?></span>
        </p>
        <hr>
        <br>
        <div class="colbox">
            <div class="colbox-2">
                <h2 class="c-pop fontem-10">Escolher o meio de pagamento</h2>
                <br>
                <a href="javascript:addCredencies()" id="addCredencies" class="btn btn-popmartin-trans">
                    <i class="fa fa-credit-card"></i>
                    cartão de crédito</a>
                <a href="javascript:payBillet()" class="btn btn-popmartin-trans">
                    <i class="fa fa-barcode"></i>
                    boleto</a>
                <p></p>
                
                
                
                
                
            </div>
            <div class="colbox-2">
                <h2 class="c-pop fontem-10">Dados da entrega</h2>
                <br>
                <div class="colbox">
                    <div class="colbox-full">
                        <span><span class="fontw-500 c-graydark">Forma de envio: </span><?php echo e($order->freight->name); ?></span>
                        <br>
                        <span><span class="fontw-500 c-graydark">Prazo de postagem:</span> <?php echo e($order->stores); ?></span>
                        <br>
                        <span class="fontw-500 c-graydark">Prazo de entrega:</span> prazo de postagem da loja + 3 dias
                        <br>
                        <p><span class="fontw-500 c-graydark">Endereço:</span>
                            Rua Don Antônio Cabral 117, São Luíz, Volta Redonda - RJ
                        </p>
                    </div>
                </div>
            </div>
        </div>
        <div class="clear-both"></div>
        <br>
        <hr>
        <br>
        <h2 class="c-pop fontem-10">Dados dos produtos</h2>
        <br>
        <div class="padding15-30">
            <div class="colbox">
                <div class="colbox-2">
                    <img src="<?php echo e(url('/imagem/loja/'.$order->store->logo_file.'?w=50&h=50&fit=crop')); ?>" title=""
                         alt="<?php echo e($order->store->name); ?>" class="vertical-middle">
                    <p class="dp-inblock vertical-middle">
                        <span class="fontem-14"><?php echo e($order->store->name); ?></span><br>
                        <span class="dp-inblock"><b class="c-graydark">Pedido</b> nº: <?php echo e($order->key); ?> -</span>
                        <span class="dp-inblock"><b
                                    class="c-graydark">Data:</b> <?php echo e($order->created_at->format('d/m/Y H:i:s')); ?></span>
                    </p>
                </div>
                <div class="colbox-2">

                </div>
            </div>
            <div class="clear-both"></div>
        </div>
        <table class="table">
            <thead>
            <tr>
                <th>Produto</th>
                <th>quantidade</th>
                <th>valor unitário</th>
                <th>subtotal</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $order->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td><?php echo e($product->name); ?></td>
                    <td><?php echo e($product->pivot->quantity); ?></td>
                    <td><?php echo e(real($product->pivot->unit_price)); ?></td>
                    <td><?php echo e(real($product->pivot->amount)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            <tr>
                <td colspan="3" style="text-align: right">frete</td>
                <td><?php echo e(real($order->freight_price)); ?></td>
            </tr>
            <tr>
                <td colspan="3" style="text-align: right">Total</td>
                <td><?php echo e(real($order->amount)); ?></td>
            </tr>
            </tbody>
        </table>
        <div class="colbox-2">
            <br>
            <a href="/carrinho" class="c-pop"><i class="fa fa-chevron-left"></i> Voltar para o carrinho</a>
        </div>
        <div class="padding20"></div>
    </section>
    <?php echo $__env->make('layouts.parties.data_moip_checkout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>