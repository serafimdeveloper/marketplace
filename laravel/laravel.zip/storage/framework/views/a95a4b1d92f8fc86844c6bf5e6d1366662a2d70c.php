<?php $__env->startSection('content'); ?>
    <section class="content">
        <header class="pop-title">
            <h1>Meus produtos favoritos</h1>
        </header>
        <?php for($i = 0; $i < 2; $i++): ?>
            <article class="pop-cart pop-favrities">
                <h1>Loja do Juca</h1>
                <div>
                    <table class="table">
                        <thead>
                        <tr>
                            <th class="t-small"></th>
                            <th></th>
                            <th class="t-medium">Preço</th>
                        </tr>
                        </thead>
                        <tbody id="jq-pr-cart">
                        <?php for($j = 0; $j < 2; $j++): ?>
                            <tr id="pr<?php echo e($j.$i); ?>">
                                <td class="txt-center">
                                    <div class="form-modern">
                                        <div class="checkbox-container">
                                            <div class="checkboxies">
                                                <label class="checkbox" style="border: none;padding: 0;">
                                                    <span><span class="fa fa-square-o"></span></span>
                                                    <?php echo Form::checkbox('status','0'); ?>

                                                </label>
                                            </div>
                                            <span class="alert hidden"></span>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="coltable">
                                        <div class="coltable-2 product-cart-img">
                                            <img src="<?php echo e(url('imagem/produto/camisa.jpg')); ?>"
                                                 alt="[]"
                                                 title="">
                                        </div>
                                        <div class="coltable-10 product-cart-info">
                                            <p class="c-pop fontem-12 fontw-400">Nome do produto</p>
                                            <span>Código: 0gos8d4</span>
                                            <br>
                                            <br>
                                            <a class="pop-remove-product-cart c-pop" href="javascript:void(0)"><i
                                                        class="fa fa-trash"></i> remover</a>
                                        </div>
                                    </div>
                                </td>
                                <td class="price" style="font-weight: bold;">R$ 14,90</td>
                            </tr>
                        <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                </div>
            </article>
        <?php endfor; ?>
        <a href="javascript:void(0)" class="btn btn-popmartin">adicionar ao carrinho</a>
    </section>
    <div class="bs-dialog radius-small" title="Enviar observação para LOJA DO JUCA"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>