<?php $__env->startSection('content'); ?>
    <section class="content">
        <div class="pop-title">
            <h1>Pedido de compra</h1>
        </div>
        <br>
        <div class="bg-graylightextreme padding20 radius">
            <h2>Pedido número M20171382</h2>
            <span class="fontem-14 c-pop">R$ 39,90</span></p>
        </div>
        <br>
        <div class="bg-graylightextreme padding20 radius">
            <h3>Código de barras:</h3>
            <div class="content">
                <span>Copie e cole a linha digitável a seguir no site ou aplicativo do seu banco</span><br>
                <div class="dp-inblock fontem-14" style="border: 1px solid #555555; padding: 10px 40px;">
                    sdfq342wdc8-q7d0-pqv7q2g108db1pd12
                </div>
            </div>
        </div>
        <br>
        <div class="txt-center">
            <a id="payBillet" class="btn btn-popmartin" href="javascript:payBillet();">
                Imprimir Boleto
            </a>
        </div>
    </section>
    <div id="MoipWidget"
         data-token=""
         callback-method-success="moipSuccess"
         callback-method-error="moipError"></div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script
            type='text/javascript'
            src='https://desenvolvedor.moip.com.br/sandbox/transparente/MoipWidget-v2.js'
            charset='ISO-8859-1'>
    </script>
    <script type="text/javascript">
        var moipSuccess = function(response){
            console.log(response);
        };

        var moipError = function(response) {
//            JSON.stringify(response)
            console.log(response);
        };

        payBillet = function() {
            var settings = {
                "Forma": "BoletoBancario"
            }
            MoipWidget(settings);
        }
        payCredCart = function() {
            var settings = {
                "Forma": "CartaoCredito",
                "Instituicao": "Visa",
                "Parcelas": "1",
                "CartaoCredito": {
                    "Cofre": "0b2118bc-fdca-4a57-9886-366326a8a647",
                    "CodigoSeguranca": "123"
                }
            }
            MoipWidget(settings);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>