<br>
<div class="container bg-graylightextreme">
    <div class="content txt-center">
        <img src="<?php echo e(url('imagem/popmartin/SiteSeguroPopMartin.png')); ?>?w=200" alt="[Site seguro. Compra protegida]" title="Site seguro. Compra protegida">
    </div>
</div>
<div class="clear-both"></div>
<footer class="footer">
    <div class="content">
        <h1 class="font-0">Mais informações sobre PopMartin</h1>
        <div class="nav-footer-cat colbox">
            <?php $__empty_1 = true; $__currentLoopData = get_categories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                <div class="colbox-5">
                    <ul class="nav-footer">
                        <li><a href="<?php echo e(route('pages.products.categoria',['category'=>$category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                    </ul>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <?php for($i = 1; $i < 26; $i++): ?>
                    <div class="colbox-5">
                        <ul class="nav-footer">
                            <li><a href="#">categória <?php echo e($i); ?></a></li>
                        </ul>
                    </div>
                <?php endfor; ?>
            <?php endif; ?>
        </div>
        <div class="clear-both"></div>
    </div>
    <div class="content">
        <div class="colbox pop-footer-info" style="padding: 0 10px;">
            <div class="colbox-2">
                <h2 class="c-white">Formas de pagamento</h2>
                <div class="footer-icons">
                    <span class="popicon visa"></span>
                    <span class="popicon mastercard"></span>
                    <span class="popicon hiper"></span>
                    <span class="popicon elo"></span>
                    <span class="popicon cart1"></span>
                    <span class="popicon itau"></span>
                    <span class="popicon bradesco"></span>
                    <span class="popicon banco-do-brasil"></span>
                    <span class="popicon boleto"></span>
                    <span class="popicon moip"></span>
                </div>
            </div>
            <div class="colbox-2">
                <ul class="nav-footer-last">
                    <li><a href="/login">monte sua loja</a></li>
                    
                    <li><a href="/contato">fale conosco</a></li>
                    <li><a href="/pagina/termos-de-uso">termos de uso</a></li>
                    <li><a href="/pagina/politicas-de-privacidade">políticas de privacidade</a></li>
                </ul>
            </div>
            <div class="clear-both"></div>
        </div>
        <br>
        <div class="txt-center padding10 c-red">
            &copy; <?php echo e(date('Y')); ?> Pop Martin - Todos os direitos reservados
        </div>
    </div>
    <div class="clear-both"></div>
</footer>


