<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('accont.inc.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="padding20"></div>
    <section class="panel-content">
        <div class="trigger accept fontem-14"><i class="fa fa-thumbs-up"></i> Compra realizada com sucesso!</div>
        <br>
        <p class="txt-center fontem-14">
            Obrigado por confiar em nosso trabalho! Você pode acompanhar o status de seu pedido<br>
            <a class="btn btn-small btn-popmartin-trans" href="<?php echo e(route('accont.requests')); ?>">Clicando aqui!</a>
        </p>
    </section>
    <div class="clear-both"></div>
    <?php echo $__env->make('layouts.parties.alert_banner', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>