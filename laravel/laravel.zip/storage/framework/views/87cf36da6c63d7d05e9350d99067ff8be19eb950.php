<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('accont.inc.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="panel-content">
        <header class="pop-title">
            <h1>Minhas vendas</h1>
        </header>
        <?php if(!$requests->first()): ?>
            <p class="trigger notice fontem-14">Nenhuma venda foi registrada até o momento!</p>
        <?php else: ?>
            <table class="table table-action">
                <thead>
                <tr>
                    <th class="t-small">Pedido</th>
                    <th class="t-medium">Data</th>
                    <th class="t-small">Valor</th>
                    <th class="t-medium">Cliente</th>
                    <th class="t-small">Status</th>
                    <th class="t-small txt-center"><i class="fa fa-gears"></i></th>
                </tr>
                </thead>

                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $requests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $request): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td>#<?php echo e($request->key); ?></td>
                        <td><?php echo e($request->created_at->diffForHumans()); ?></td>
                        <td>R$<?php echo e(number_format($request->amount,'2',',','.')); ?></td>
                        <td><?php echo e($request->user->name); ?></td>
                        <td class="t-status t-<?php echo e($request->requeststatus->trigger); ?>"><?php echo e($request->requeststatus->description); ?></td>
                        <td class="txt-center"><a href="<?php echo e(route('accont.salesman.sale_info',$request->id)); ?>"
                                                  class="t-popmartin">detalhes</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                <?php endif; ?>
                </tbody>
            </table>
        <?php endif; ?>
        <div class="fl-right"><?php echo $requests->links(); ?></div>
        <div class="clear-both"></div>
    </section>
    <div class="clear-both"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>