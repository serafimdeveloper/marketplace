<!DOCTYPE html>
<html lang="br">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="url" content="<?php echo e(Request::url()); ?>">
        <meta name="rating" content="General">
        <meta name="revisit-after" content="7 days">
        <meta name="Revisit-After" content="1 days">
        <meta name="geo.placename" content="Brasil">
        <meta name="geo.position" content="Rio de Janeiro">
        <meta name="Robots" content="index, follow">
        <link rel="canonical" href="<?php echo e(url('/')); ?>">
        <link rel="shortlink" href="<?php echo e(Request::url()); ?>">

        <?php echo $__env->yieldContent('meta_facebook'); ?>

        <title>PopMartin</title>
        <link href="<?php echo e(asset('frontend/css/bootstrap.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('frontend/lib/owlcarousel/owl.carousel.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('frontend/lib/owlcarousel/theme/owl.theme.default.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('frontend/lib/tooltipster/css/tooltipster.bundle.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('frontend/lib/alertfy/css/alertify.min.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('frontend/lib/alertfy/css/themes/semantic.rtl.min.css')); ?>" rel="stylesheet">
        <?php echo $__env->yieldContent('css'); ?>
        <link href="<?php echo e(asset('css/popmartin.css')); ?>" rel="stylesheet">
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
        <script src="<?php echo e(asset('frontend/js/jquery1.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/lib/jqueryui/jquery-ui.min.js')); ?>"></script>
    </head>
    <body>
        <main class="container">
            <?php echo $__env->make('inc.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <?php echo $__env->yieldContent('content'); ?>
            <?php echo $__env->make('inc.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </main>
        <div id="fb-root"></div>
        <script>
            (function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s); js.id = id;
                js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.8&appId=1645780162393141";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
        </script>
        <script src="<?php echo e(asset('frontend/lib/maskinput/jquery.mask.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/lib/tooltipster/js/tooltipster.bundle.min.js')); ?>"></script>
        <script src="<?php echo e(asset('frontend/lib/alertfy/alertify.min.js')); ?>"></script>
        
        <script src="<?php echo e(asset('frontend/js/bootstrap.js')); ?>"></script>
        <script src="<?php echo e(asset('/js/popmartin.js')); ?>"></script>

        <?php echo $__env->yieldContent('script'); ?>

        <?php if(session()->has('flash_notification.message')): ?>
            <script>
                var alert = '<?php echo e(session('flash_notification.level')); ?>';
                var message = '<?php echo session('flash_notification.message'); ?>';
                if(alert == 'accept'){
                    alertify.success(message);
                }else{
                    alertify.error(message);
                }
            </script>
        <?php endif; ?>
    </body>
</html>