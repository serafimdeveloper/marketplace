<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('accont.inc.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <section class="panel-content">
        <header class="pop-title">
            <h1>Minhas informações de Vendedor</h1>
        </header>
        <?php if(isset($salesman)): ?>
            <?php echo Form::model($salesman,['url' => '/accont/salesman/update', 'method' => 'POST', 'class' => 'form-modern pop-form', 'enctype'=>'multipart/form-data']); ?>

        <?php else: ?>
            <?php echo Form::open(['route' => ['accont.salesman.store'], 'method' => 'POST', 'class' => 'form-modern pop-form', 'enctype'=>'multipart/form-data']); ?>

        <?php endif; ?>
        <div class="colbox">
            <div class="colbox-2">
                <label>
                    <span>CPF <sup class="c-red fontem-06 fl-right">obrigatório</sup></span>
                    <?php echo Form::text(null, Auth::user()->cpf, ['disable' => true]); ?>

                    <span class="alert<?php echo e($errors->has('cpf') ? '' : ' hidden'); ?>"><?php echo e($errors->first('cpf')); ?></span>

                </label>
                <label>
                    <span>Telefone fixo <sup class="c-red fontem-06 fl-right">obrigatório</sup></span>
                    <?php echo Form::text('phone', null, ['class' => 'masked_phone', 'data-required' => 'fullphone']); ?>

                    <span class="alert<?php echo e($errors->has('phone') ? '' : ' hidden'); ?>"><?php echo e($errors->first('phone')); ?></span>

                </label>
                <label>
                    <span>Telefone celular <sup class="c-red fontem-06 fl-right">obrigatório</sup></span>
                    <?php echo Form::text('cellphone', null, ['class' => 'masked_fullphone', 'data-required' => 'fullphone']); ?>

                    <span class="alert<?php echo e($errors->has('cellphone') ? '' : ' hidden'); ?>"><?php echo e($errors->first('cellphone')); ?></span>

                </label>
                <label>
                    <span>Whatsapp</span>
                    <?php echo Form::text('whatsapp', null, ['class' => 'masked_fullphone', 'data-required' => 'whatsapp']); ?>

                    <span class="alert<?php echo e($errors->has('whatsapp') ? '' : ' hidden'); ?>"><?php echo e($errors->first('whatsapp')); ?></span>

                </label>
                <br>

                <div class="form-modern">
                    <br>
                    <p class="c-pop fontw-800">Envio de documentos <sup class="c-red fontem-06 fl-right">obrigatório</sup></p>
                    <?php if(!isset($salesman->photo_document) || !isset($salesman->proof_adress)): ?>
                        <p>
                            Para que seja autorizado o uso do Pop Martin como vendedor, você precisa
                            enviar uma cópia digitalizável e legível de um documento seu com foto(RG, CNH)
                            e de um comprovante de residência que esteja em seu nome.
                        </p>
                    <?php endif; ?>


                    <div class="txt-center">
                        <?php if(!$isDocs['document']): ?>
                            <p>Documento com foto (formato PNG ou JPG)</p>
                            <div class="file" style="border:1px solid #B0BEC5;padding: 10px;">
                                <?php echo Form::file('photo_document'); ?>

                                <input type="text" value="<?php echo e(old('photo_document')); ?>">
                                <button type="button" class="btn btn-orange">imagem</button>
                                <div class="clear-both"></div>
                                <span class="alert<?php echo e($errors->has('photo_document') ? '' : ' hidden'); ?>"><?php echo e($errors->first('photo_document')); ?></span>
                            </div>
                        <?php else: ?>
                            <p>
                                <img src="<?php echo e(url('imagem/vendedor/'.$salesman->photo_document.'?w=180&h=120')); ?>"><br>
                                Documento com foto enviado
                            </p>
                        <?php endif; ?>
                        <br>
                        <?php if(!$isDocs['document']): ?>
                            <p>Comprovante de residência (formato PNG ou JPG ou PDF)</p>
                            <div class="file" style="border:1px solid #B0BEC5;padding: 10px;">
                                <?php echo Form::file('proof_adress'); ?>

                                <input type="text" value="<?php echo e(old('proof_adress')); ?>">
                                <button type="button" class="btn btn-orange">imagem</button>
                                <div class="clear-both"></div>
                                <span class="alert<?php echo e($errors->has('proof_adress') ? '' : ' hidden'); ?>"><?php echo e($errors->first('proof_adress')); ?></span>
                            </div>
                        <?php else: ?>
                            <p>
                                <img src="<?php echo e(url('imagem/vendedor/'.$salesman->proof_adress.'?w=180&h=120')); ?>"><br>
                                Comprovante de endereço enviado
                            </p>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="colbox-2">
                
                <p class="c-pop padding05 fontw-800">O que é MoIP?</p>
                <p>
                    O MoIP é uma empresa de pagamentos online que possibilita o envio e recebimento
                    de dinheiro via internet. Através da sua conta no MoIP você receberá pelas suas
                    vendas no Pop Martin e consequentemente aceitará compras feitas com cartão de
                    crédito, cartão de débito, boleto e débito online. Sem uma conta de vendedor no
                    MoIP não é possível ativar a sua loja e vender no Pop Martin.</p>
                <a href="https://moip.com.br/" class="btn btn-small btn-popmartin" target="_blank">Saiba mais</a>
                <div class="padding10"></div>
                <p class="c-pop padding05 fontw-800">Já me cadastrei no Moip</p>
                <p>
                    Após concluir o seu cadastro, preencha o campo abaixo com o login fornecido pelo MOIP
                </p>
                <label>
                    <span>login MOIP <sup class="c-red fontem-06 fl-right">obrigatório</sup></span>
                    <?php echo Form::text('moip', null, ['placeholder' => 'meulogin']); ?>

                    <span class="alert<?php echo e($errors->has('moip') ? '' : ' hidden'); ?>"><?php echo e($errors->first('moip')); ?></span>

                </label>
                <div class="padding10"></div>
                <p class="c-pop padding05 fontw-800">Ainda não me cadastrei no MOIP</p>
                <p>
                    Cadastre-se como vendedor no MoIP e comece a vender no Pop Martin aceitando
                    cartões de crédito, débito, boleto e débito online. O cadastro demora alguns
                    minutos e requer apenas informações simples como nome, endereço, e-mail, RG e CPF.
                </p>
                <a href="https://cadastro.moip.com.br/" class="btn btn-small btn-popmartin" target="_blank">cadastrar
                    no
                    MOIP</a>
            </div>
        </div>
        <div class="txt-center">
            <button type="submit" class="btn btn-popmartin"
                    style="margin-top:15px"><?php echo e(isset($salesman) ? 'atualizar' : 'gravar'); ?></button>
        </div>
        <?php echo Form::close(); ?>

    </section>
    <div class="clear-both"></div>
    <?php echo $__env->make('layouts.parties.alert_adress', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>