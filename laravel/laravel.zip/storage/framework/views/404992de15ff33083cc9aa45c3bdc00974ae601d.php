<?php if(Request::segment(1) == 'accont'): ?>
    <header class="pop-header" style="background: none; height: 43px;">
        <div class="pop-top-header panel-top-header">
            <?php else: ?>
                <header class="pop-header">
                <div class="pop-top-header">
                    <?php endif; ?>
                    <div class="content">
                        <div class="pop-logo"><a href="<?php echo e(route('homepage')); ?>" title="página inicial"></a></div>
                        <div class="navicon-mobile"><i class="fa fa-navicon c-popdark"></i></div>
                        <div class="nav-mobile pop-top-nav">
                            <div class="header-search">
                                <form class="form pop-search" action="/pesquisa" method="get">
                                    <div class="input-group">
                                        <input type="text" name="search" placeholder="o que procura?" value="<?php echo e(isset($search) ? $search : ''); ?>">
                                        <button type="submit"><i class="fa fa-search"></i></button>
                                    </div>
                                </form>
                            </div>
                            <div class="header-menu">
                                <div class="facebook">
                                    <a class="" href="https://www.facebook.com/popmartinbrasil/" target="_blank"><i
                                                class="fa fa-facebook-official c-facebook vertical-middle"></i> </a>
                                </div>
                                <div class="favorite">
                                    <a class="<?php echo e(Auth::check() ? '' : 'jq-auth'); ?>" data-message=" para visualizar seus favoritos!" href="/favoritos"><i class="fa fa-heart c-reddark vertical-middle"></i> </a>
                                </div>
                                <div class="cart">
                                    <a class="vertical-middle" href="/carrinho">
                                        <i class="fa fa-shopping-cart c-green-avocadodark vertical-middle"></i>
                                        <div class="dp-inblock fontem-07 txt-center" id="amount-cart">
                                            <span class="c-green fontw-500"><?php echo e(amount_cart()); ?></span>
                                        </div>
                                    </a>
                                </div>
                                <div class="menu">
                                    <?php if(Auth::check()): ?>
                                        <a class="" href="javascript:void(0)"><i
                                                    class="fa fa-user-circle-o c-popdark vertical-middle"></i>
                                            <span class="c-popdark">Olá, <?php echo e(Auth::user()->name); ?> <i
                                                        class="fa fa-caret-down vertical-middle"></i></span></a>
                                        <div class="menu-hidden">
                                            <ul>
                                                <li><a href="/accont">minha conta</a>
                                                </li>
                                                <li><a href="/logout">sair</a>
                                                </li>
                                            </ul>
                                        </div>
                                    <?php else: ?>
                                        <a href="/login" title="entrar">
                                            <span class="c-popdark"
                                                  tyle="vertical-align: super;">registrar/entrar</span>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="clear-both"></div>
                </div>
                <?php if(Request::segment(1) != 'accont'): ?>
                    <div class="content-ads">
                        <div class="pop-ads owl-carousel">
                            <?php $__empty_1 = true; $__currentLoopData = banner_ads(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                            <div class="vertical-flex">
                                <img src="<?php echo e($ad['image']); ?>" title="" alt="[]">
                                <p><?php echo e($ad['name']); ?> <br> <span><?php echo e($ad['description']); ?></span></p>
                                <a href="<?php echo e($ad['url']); ?>"></a>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                                <?php for($i=0;$i<5;$i++): ?>
                                    <div class="vertical-flex">
                                        <img src="<?php echo e(url('imagem/popmartin/img-exemple.jpg?w=100&h=100&fit=crop')); ?>" title="" alt="[]">
                                        <p>sua loja aqui <br> <span>acesso rápido e maior visibilidade</span></p>
                                        <a href="#"></a>
                                    </div>
                                <?php endfor; ?>
                            <?php endif; ?>
                        </div>
                        <div class="clear-both"></div>
                    </div>
                    <div class="pop-nav-main">
                        <div class="pop-nav-content">
                            <div class="navicon-mobile c-white" style="float: left;margin-left: 15px;"><i
                                        class="fa fa-navicon c-popdark vertical-middle" style="color: #FFF;font-size: 0.875em"></i> <span
                                        class="fontem-06" style="vertical-align: middle;">categorias</span></div>
                            <div class="clear-both"></div>
                            <ul class="nav nav-mobile">
                                <?php $__empty_1 = true; $__currentLoopData = get_categories(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); $__empty_1 = false; ?>
                                    <li><a href="<?php echo e(route('pages.products.categoria',['category'=>$category->slug])); ?>"><?php echo e($category->name); ?></a></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); if ($__empty_1): ?>
                                    <?php for($i=1;$i<9;$i++): ?>
                                        <li><a href="">menu <?php echo e($i); ?></a></li>
                                    <?php endfor; ?>
                                <?php endif; ?>
                            </ul>
                        </div>
                    </div>
    <?php endif; ?>
</header>
<div class="clear-both"></div>