@extends('layouts.app')

@section('content')
    <section class="content">
        {{--<header class="pop-title">--}}
            {{--<h1>Fale conosco</h1>--}}
        {{--</header>--}}
    </section>
@endsection