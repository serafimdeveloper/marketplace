 <ul>
     <li> - 27/02/2017 Leitura de produtos na homepage iniciada (80%)</li>
     <li> - 27/02/2017 Leitura de produto específico iniciada (70%)</li>
     <li> - 27/02/2017 Carrinho iniciado (10%)</li>
 </ul>