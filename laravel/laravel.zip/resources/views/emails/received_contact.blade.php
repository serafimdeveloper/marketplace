<div style="text-align: justify; font-size: 14px; font-family: Arial,Helvetica,Sans-Serif">
    <p style="font-size: 16px; font-weight: bold; color: #800000">Mensagem envida por {{ $data['name'] }}</p>

    <p>
        {{ $data['message'] }}
    </p>
</div>