<html>
<head>
    <title>Checkout Transparente - Boleto</title>
    <meta name="author" content="Moip Pagamentos S/A" />
    <meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />

    <link href="/public/frontend/css/bootstrap.css" rel="stylesheet">
</head>
<body>
    <div class="content">
        <a href="" class="btn btn-green">Pagar</a>
    </div>
</body>
</html>