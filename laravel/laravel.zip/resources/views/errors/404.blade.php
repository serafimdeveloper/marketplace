@extends('layouts.app')

@section('content')
    <section class="content">
        <header class="pop-title">
            <h1>Página não encontrada</h1>
        </header>
        <p>
            Essa página não pode ser exibida!
        </p>
    </section>

@endsection