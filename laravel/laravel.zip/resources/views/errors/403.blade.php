@extends('layouts.app')

@section('content')
    <section class="content">
        <header class="pop-title">
            <h1>Loja não dispoível</h1>
        </header>
        <p>
            Essa loja não está disponível nesse momento, por favor tente mais tarde!
        </p>
    </section>

@endsection